10 gold chain images (1000x1000 PNG, transparent background, front view).
Use them in Admin > upload as the "Try-on image". Name each product to match the file name.
Chain order: Rope, Box, Heart Curb, Figaro, Cuban, Snake, Mariner, Wheat, Byzantine+Coin, Haram+Teardrop.
For real products, replace with your own photos: front view, background removed (remove.bg), plain white/black not needed.
